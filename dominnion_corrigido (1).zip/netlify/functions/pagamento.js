// Cria uma preferência do Mercado Pago (Checkout Pro) no servidor.
// O Access Token nunca é enviado ao navegador.
const { cat, J, pv, linhas, cotar } = require('./_comum');

const textoErroMP = d => {
  if (!d || typeof d !== 'object') return '';
  const causas = Array.isArray(d.cause) ? d.cause.map(x => x.description || x.code).filter(Boolean).join('; ') : '';
  return [d.message, causas].filter(Boolean).join(' — ').slice(0, 500);
};

exports.handler = async e => {
  if (e.httpMethod !== 'POST') return J(405, { erro: 'Método inválido' });
  try {
    if (!process.env.MP_ACCESS_TOKEN) return J(503, { erro: 'Mercado Pago não configurado: confira MP_ACCESS_TOKEN nas variáveis do Netlify.' });

    let b;
    try { b = JSON.parse(e.body || '{}'); }
    catch (_) { return J(400, { erro: 'Dados do pedido inválidos.' }); }

    const c = b.cliente || {};
    const cep = String(b.cep || '').replace(/\D/g, '');
    if (cep.length !== 8 || !c.nome || !/^\S+@\S+\.\S+$/.test(c.email || '') || !c.endereco) {
      return J(400, { erro: 'Dados incompletos. Confira nome, e-mail, endereço e CEP.' });
    }

    const siteBruto = process.env.SITE_URL || process.env.URL;
    let site;
    try { site = new URL(siteBruto).origin; }
    catch (_) { return J(503, { erro: 'Endereço do site não configurado. Defina SITE_URL no Netlify (ex.: https://seudominio.com.br).' }); }

    const ls = await linhas(b.items, e);
    const opcoesFrete = await cotar(cep, ls);
    const frete = opcoesFrete.find(o => String(o.id) === String(b.freteId));
    if (!frete) return J(400, { erro: 'A opção de frete expirou. Calcule o frete novamente e tente pagar.' });

    const pc = Number(cat.cupons[String(b.cupom || '').toUpperCase()] || 0);
    const ref = 'DOM-' + Date.now().toString(36).toUpperCase();
    const preference = {
      items: ls.map(({ p, q }) => ({
        id: String(p.id), title: String(p.nome).slice(0, 250), quantity: q,
        currency_id: 'BRL', unit_price: +(pv(p) * (1 - pc / 100)).toFixed(2)
      })),
      payer: {
        name: String(c.nome).slice(0, 100), email: String(c.email).trim(),
        phone: { number: String(c.tel || '').replace(/\D/g, '').slice(0, 20) }
      },
      shipments: {
        mode: 'not_specified', cost: +Number(frete.valor).toFixed(2),
        receiver_address: { zip_code: cep, street_name: String(c.endereco).slice(0, 200) }
      },
      back_urls: {
        success: `${site}/?pedido=ok&ref=${ref}`,
        pending: `${site}/?pedido=pendente&ref=${ref}`,
        failure: `${site}/?pedido=erro&ref=${ref}`
      },
      auto_return: 'approved', external_reference: ref,
      statement_descriptor: 'DOMINNION',
      notification_url: `${site}/.netlify/functions/webhook`,
      metadata: {
        cliente: { nome: c.nome, cidade: c.cidade || '', email: c.email, tel: c.tel || '', endereco: c.endereco },
        cep, frete, cupom: pc ? String(b.cupom).toUpperCase() : null,
        itens: ls.map(({ p, q }) => ({ id: p.id, nome: p.nome, q }))
      }
    };

    const r = await fetch('https://api.mercadopago.com/checkout/preferences', {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + process.env.MP_ACCESS_TOKEN,
        'Content-Type': 'application/json', Accept: 'application/json'
      },
      body: JSON.stringify(preference)
    });
    const d = await r.json().catch(() => ({}));

    if (!r.ok) {
      console.error('Mercado Pago preference error:', r.status, textoErroMP(d) || 'resposta sem detalhes');
      return J(502, { erro: `Mercado Pago recusou a criação do pagamento (HTTP ${r.status}). ${textoErroMP(d) || 'Confira as credenciais e os dados da preferência.'}` });
    }
    if (!d.init_point || typeof d.init_point !== 'string') {
      console.error('Mercado Pago sem init_point:', JSON.stringify({ id: d.id, keys: Object.keys(d || {}) }));
      return J(502, { erro: 'Mercado Pago não retornou o link de checkout. Confira o log da função pagamento no Netlify.' });
    }

    return J(200, { url: d.init_point, ref, preferenceId: d.id });
  } catch (err) {
    console.error('Erro na função pagamento:', err && err.stack ? err.stack : err);
    return J(500, { erro: err && err.message ? err.message : 'Erro interno ao iniciar o pagamento.' });
  }
};
